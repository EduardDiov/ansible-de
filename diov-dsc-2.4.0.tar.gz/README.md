# Ansible Collection - diov.sc (Server creation)

Create debian-based server with configured ssh access, all apps and docker installed.
